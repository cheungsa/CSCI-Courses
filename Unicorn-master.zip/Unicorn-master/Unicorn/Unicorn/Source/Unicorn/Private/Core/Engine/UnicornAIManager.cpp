// Copyright 2018 Team Unicorn All Rights Reserved

#include "UnicornAIManager.h"


// Sets default values
AUnicornAIManager::AUnicornAIManager()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AUnicornAIManager::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AUnicornAIManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

