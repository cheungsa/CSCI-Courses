// Fill out your copyright notice in the Description page of Project Settings.

#include "VRGripInterface.h"
#include "UObject/ObjectMacros.h"
#include "UObject/Interface.h"
 
UVRGripInterface::UVRGripInterface(const class FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
 
}