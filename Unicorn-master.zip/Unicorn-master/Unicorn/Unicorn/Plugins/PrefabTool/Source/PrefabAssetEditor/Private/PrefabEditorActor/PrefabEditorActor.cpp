// Copyright 2017 marynate. All Rights Reserved.

#pragma once

#include "PrefabActor.h"
#include "PrefabComponent.h"
#include "PrefabAsset.h"
#include "PrefabToolHelpers.h"

#define LOCTEXT_NAMESPACE "PrefabEditorActor"


#undef LOCTEXT_NAMESPACE